from django.apps import AppConfig


class AppConfig(AppConfig):
    name = 'app'

class UsersConfig(AppConfig):
    name = 'users'