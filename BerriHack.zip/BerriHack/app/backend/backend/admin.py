from django.contrib import admin

# admin.site.register(Profile)
# admin.site.register(Modules)
# admin.site.register(Multiplayer)