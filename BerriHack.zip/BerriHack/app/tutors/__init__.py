# store all logic for rendering users (generate sample set of tutors)
# filter based on category
# render grid of sample tutor profiles with psuedonames and category specialities and if parameters match, display given profiles that match parameters

